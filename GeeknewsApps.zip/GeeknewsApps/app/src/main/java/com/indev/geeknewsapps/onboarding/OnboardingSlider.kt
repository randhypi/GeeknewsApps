package com.indev.geeknewsapps.onboarding

class OnboardingSlider (
    val title : String,
    val description : String,
    val icon : Int
)