package com.indev.geeknewsapps.ui._model

class ModelData (

    var title: String= "",
    var subTitle: String= "",
    var description: String= "",
    var category: String= "",
    var postTime: String= "",
    var postBy: String= "",
    var imagesUrl: String= "",
    var youtubeUrl: String= ""
)